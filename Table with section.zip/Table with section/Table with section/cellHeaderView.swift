//
//  cellHeaderView.swift
//  Table with section
//
//  Created by Appnotrix on 30/1/23.
//

import UIKit

class cellHeaderView: UITableViewCell {

    @IBOutlet weak var txtHeaderLabel: UILabel!
    
    override func awakeFromNib() {
        super.awakeFromNib()
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)
    }
    
}
