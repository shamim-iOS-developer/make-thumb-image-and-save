//
//  ViewController.swift
//  Table with section
//
//  Created by Appnotrix on 30/1/23.
//

import UIKit

class ViewController: UIViewController, UITableViewDelegate, UITableViewDataSource {
    
    @IBOutlet weak var sectionTableView: UITableView!
    let cellData = [["Shamim Munshi", "Suhag Hossain"],["Sakib","Motiur","Another"], ["MD Hosne Mubarak", "Md Chinmoy"],["MD Masudur Rahman", "MD Moshfiqur Rahman"]]
    
    let sectionTitle = ["Intern", "Graphic Designer", "Developer","Admin"]
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        sectionTableView.delegate = self
        sectionTableView.dataSource = self
                
        sectionTableView.register(UINib(nibName: "cellHeaderView", bundle: nil), forCellReuseIdentifier: "cellHeaderView")

    }
    
//    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
//        return cellData[section].count
//    }
//    
//    func numberOfSections(in tableView: UITableView) -> Int {
//        return cellData.count
//    }
//    
//    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
//        let tempArry = cellData[indexPath.section]
//        let cell = sectionTableView.dequeueReusableCell(withIdentifier: "cell", for: indexPath)
//        cell.textLabel?.text = tempArry[indexPath.row]
//        return cell
//    }
//    
////    func tableView(_ tableView: UITableView, titleForHeaderInSection section: Int) -> String? {
////        return sectionTitle[section]
////    }
//    
//    func tableView(_ tableView: UITableView, heightForHeaderInSection section: Int) -> CGFloat {
//        180
//    }
//    
//    func tableView(_ tableView: UITableView, viewForHeaderInSection section: Int) -> UIView? {
//        let view = sectionTableView.dequeueReusableCell(withIdentifier: "cellHeaderView") as! cellHeaderView
//        view.txtHeaderLabel.text = sectionTitle[section]
//        return view
//    }
    
    func numberOfSections(in tableView: UITableView) -> Int {
        cellData.count
    }

    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        cellData[section].count
    }
    
    func tableView(_ tableView: UITableView, viewForHeaderInSection section: Int) -> UIView? {
        let sectionView = Bundle.main.loadNibNamed("cellHeaderView", owner: self, options: nil)?.first as! cellHeaderView
        sectionView.txtHeaderLabel.text = sectionTitle[section]
        return sectionView
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = sectionTableView.dequeueReusableCell(withIdentifier: "cell")
        let arr = cellData[indexPath.section]
        cell?.textLabel?.text = arr[indexPath.row]
        return cell!
    }
    
}

