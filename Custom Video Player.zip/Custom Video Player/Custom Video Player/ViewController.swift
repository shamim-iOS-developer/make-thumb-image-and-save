//
//  ViewController.swift
//  Custom Video Player
//
//  Created by Appnotrix on 5/2/23.
//

import UIKit
import AVFoundation
import AVKit
import Photos

class ViewController: UIViewController {
    
    @IBOutlet weak var videoView: UIView!
    @IBOutlet weak var thumbImageView: UIImageView!
    @IBOutlet weak var sliderScrollView: UIScrollView!
    @IBOutlet weak var sliderView: UISlider!
    @IBOutlet weak var startTimeLabel: UILabel!
    @IBOutlet weak var endTimeLabel: UILabel!
    @IBOutlet weak var playPauseButton: UIButton!
    
    var player: AVPlayer!
    var avpController = AVPlayerViewController()
    var selectedVideoUrl: URL!
    var videoDuration : Double!
    var assets : AVAsset!
    var isPlay : Bool = false
    var imageForScroolView : [UIImage?] = []
    var timer : Timer!
    
    var yOffSet: CGFloat = -200.0
    var scrollCurrentTime = 0.0
    
    override func viewDidLoad() {
        super.viewDidLoad()
        thumbImageView.image = UIImage(systemName: "plus")
        DispatchQueue.main.async { [self] in
            setImageInScroolView(image: imageForScroolView)
        }
        
        //MARK: - Play Local Video
        thumbImageView.isHidden = true // Hide Thumb image
        guard let filePath = Bundle.main.path(forResource: "abc", ofType: ".mp4") else { return }
        let fileURL = URL(fileURLWithPath: filePath)
        selectedVideoUrl = fileURL
        playVideo(videoUrl: fileURL)
        thumbnailForVideoAtURL(url: fileURL)
        if let image = imageForScroolView[0]{
            thumbImageView.image = image
        }
        sliderScrollView.contentOffset.x = yOffSet
    }

    @IBAction func playPauseButton(_ sender: UIButton) {
        if isPlay{
            player.pause()
            playPauseButton.setImage(UIImage(systemName: "play.fill"), for: .normal)
            isPlay = false
        }else{
            player.play()
            playPauseButton.setImage(UIImage(systemName: "pause.fill"), for: .normal)
            isPlay = true
            timer = Timer.scheduledTimer(timeInterval: 0.01, target: self, selector: #selector(timerAction), userInfo: nil, repeats: true)
        }
    }
    
    //MARK: - Playing Video Method by video url
    func playVideo(videoUrl: URL) {
        assets = AVAsset(url: videoUrl)
        player = AVPlayer(url: videoUrl)
        player.externalPlaybackVideoGravity = .resize //.resizeAspectFill
        avpController.player = player
        avpController.view.frame.size.height = videoView.frame.size.height
        avpController.view.frame.size.width = videoView.frame.size.width
        avpController.showsPlaybackControls = false
        self.videoView.addSubview(avpController.view)
        player.pause()
        endTimeLabel.text = getTimeString(from: assets.duration)
    }
    
    //MARK: - Auto Scroll Scrollview
    @objc func timerAction() {
        if isPlay{
            if assets.duration.seconds > scrollCurrentTime{
                startTimeLabel.text = getTimeString(from: CMTime(seconds: scrollCurrentTime, preferredTimescale: 1))
                yOffSet += 1.8;
                sliderView.setValue(Float(scrollCurrentTime) / Float(assets.duration.seconds), animated: true)
                sliderScrollView.contentOffset.x = yOffSet
                scrollCurrentTime += 0.01
            }else{
//                self.player?.seek(to: CMTime.zero)
                player.seek(to: .zero)
                player.pause()
                playPauseButton.setImage(UIImage(systemName: "play.fill"), for: .normal)
                isPlay = false
                timer.invalidate()
                scrollCurrentTime = 0.0
                yOffSet = -200.0
                sliderScrollView.contentOffset.x = yOffSet
            }
        }
    }
    
    //Get Time to String for display Time
    func getTimeString(from time: CMTime) -> String {
        let totalSeconds = CMTimeGetSeconds(time)
        print(totalSeconds)
        let hours = Int(totalSeconds/3600)
        let minutes = Int(totalSeconds/60) % 60
        let seconds = Int(totalSeconds.truncatingRemainder(dividingBy: 60))
        if hours > 0 {
            return String(format: "%i:%02i:%02i", arguments: [hours,minutes,seconds])
        }else {
            return String(format: "%02i:%02i", arguments: [minutes,seconds])
        }
    }
    
    //MARK: - Set image in scrollview
    func setImageInScroolView(image: [UIImage?]){
        let stackView = UIStackView()
        sliderScrollView.addSubview(stackView)
        stackView.axis = .horizontal
        stackView.translatesAutoresizingMaskIntoConstraints = false
        stackView.topAnchor.constraint(equalTo: sliderScrollView.topAnchor).isActive = true
        stackView.leftAnchor.constraint(equalTo: sliderScrollView.leftAnchor).isActive = true
        stackView.rightAnchor.constraint(equalTo: sliderScrollView.rightAnchor).isActive = true
        stackView.bottomAnchor.constraint(equalTo: sliderScrollView.bottomAnchor).isActive = true
        stackView.heightAnchor.constraint(equalTo: sliderScrollView.heightAnchor).isActive = true
        for img in image{
            let imageView = UIImageView()
            imageView.image = img
//            thumbImageView.image = img
            stackView.addArrangedSubview(imageView)
            imageView.contentMode = .scaleAspectFill
            imageView.heightAnchor.constraint(equalTo: stackView.heightAnchor).isActive = true
            imageView.widthAnchor.constraint(equalToConstant: 180).isActive = true
        }
    }
    func thumbnailForVideoAtURL(url: URL) {
        
        let asset = AVAsset(url: url)
        let assetImageGenerator = AVAssetImageGenerator(asset: asset)

//        var time = asset.duration
//        time.value = min(time.value, 22)
//
//        do {
//            let imageRef = try assetImageGenerator.copyCGImage(at: time, actualTime: nil)
//            return UIImage(cgImage: imageRef)
//        } catch {
//            print("error")
//            return nil
//        }
        
        for i in 0..<Int(asset.duration.seconds){
            let timea = CMTimeMake(value: Int64(i), timescale: 1)
            do {
                let imageRef = try assetImageGenerator.copyCGImage(at: timea, actualTime: nil)
                imageForScroolView.append(UIImage(cgImage: imageRef))
            } catch {
                print("error")
            }
        }
    }
}

//extension AVAsset {
//MARK: - Uses
//        DispatchQueue.main.async { [self] in
//            let url = Bundle.main.url(forResource: "abc", withExtension: ".mp4")
//            AVAsset(url: url!).generateThumbnail { [weak self] (image) in
//                            DispatchQueue.main.async {
//                                guard let image = image else { return }
//                                self?.thumbImageView.image = image
//                            }
//                        }
//        }
//
//    func generateThumbnail(completion: @escaping (UIImage?) -> Void) {
//        DispatchQueue.global().async {
//            let imageGenerator = AVAssetImageGenerator(asset: self)
//            let time = CMTime(seconds: 0.0, preferredTimescale: 600)
//            let times = [NSValue(time: time)]
//            imageGenerator.generateCGImagesAsynchronously(forTimes: times, completionHandler: { _, image, _, _, _ in
//                if let image = image {
//                    completion(UIImage(cgImage: image))
//                } else {
//                    completion(nil)
//                }
//            })
//        }
//    }
//}
