//
//  AddImageViewController.swift
//  Gellery App
//
//  Created by Appnotrix on 25/1/23.
//

import UIKit

protocol DelegateInsertImage : AnyObject{
    func insertImage(imageURL: URL)
}

class AddImageViewController: UIViewController {
    
    @IBOutlet weak var pickedImageView: UIImageView!
    var folder : URL?
    weak var insertDelegate : DelegateInsertImage?
    
    override func viewDidLoad() {
        super.viewDidLoad()
    }
    
    @IBAction func choseImageButton(_ sender: UIButton) {
        let imagePic = UIImagePickerController()
        imagePic.delegate = self
        self.present(imagePic, animated: true, completion: nil)
    }
    
    @IBAction func saveImageButton(_ sender: UIButton) {
        let fileName = folder!.appendingPathComponent("Image_" + UUID().uuidString+".jpg")
        do{
            if let imgData = pickedImageView.image?.jpegData(compressionQuality: 1), !FileManager.default.fileExists(atPath: fileName.path){
                try imgData.write(to: fileName)
                self.insertDelegate?.insertImage(imageURL: fileName)
                self.navigationController?.popViewController(animated: true)
            }
        }catch{}
    }
}

extension AddImageViewController : UIImagePickerControllerDelegate, UINavigationControllerDelegate{
    func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [UIImagePickerController.InfoKey : Any]) {
        self.dismiss(animated: true, completion: nil)
        if let image = info[.originalImage] as? UIImage{
            pickedImageView.image = image
        }
    }
}
