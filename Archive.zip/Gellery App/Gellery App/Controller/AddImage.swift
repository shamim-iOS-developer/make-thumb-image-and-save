//
//  AddImage.swift
//  Gellery App
//
//  Created by Appnotrix on 25/1/23.
//

import UIKit

class AddImage: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
    }
}
