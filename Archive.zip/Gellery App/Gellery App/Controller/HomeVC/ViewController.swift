//
//  ViewController.swift
//  Gellery App
//
//  Created by Appnotrix on 25/1/23.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var imageCollectionView: UICollectionView!
    
    var folderNameArray: [URL] = []
    
    override func viewDidLoad() {
        super.viewDidLoad()
        imageCollectionView.dataSource = self
        imageCollectionView.delegate = self
        imageCollectionView.register(UINib(nibName: "FolderCollectionViewCell", bundle: nil), forCellWithReuseIdentifier: "FolderCollectionViewCell")
        
        folderNameArray = loadAllFolder()
    }
    
    @IBAction func addFolderButton(_ sender: UIBarButtonItem) {
        let action = UIAlertController(title: "Add Folder", message: "Enter Folder Information", preferredStyle: .alert)
        action.addTextField { UITextField in
            UITextField.placeholder = "Enter Folder Name..."
        }
        action.addAction(UIAlertAction(title: "Save Folder", style: .default, handler: { [self] UIAlertAction in
            if let txtFolderName = action.textFields![0].text{
                var path = createFolder(name: txtFolderName)
                self.imageCollectionView?.performBatchUpdates({
                    let indexPath = IndexPath(row: folderNameArray.count, section: 0)
                    folderNameArray.append(path) //add your object to data source first
                    self.imageCollectionView?.insertItems(at: [indexPath])
                }, completion: nil)
            }
        }))
        action.addAction(UIAlertAction(title: "Cancel", style: .cancel, handler: nil))
        self.present(action, animated: true, completion: nil)
    }
    
    func createFolder(name: String) -> URL{
        let docDir = NSURL(fileURLWithPath: NSSearchPathForDirectoriesInDomains(.documentDirectory, .userDomainMask, true)[0])
        let dirPath = docDir.appendingPathComponent(name)
        do{
            try FileManager.default.createDirectory(atPath: dirPath!.path, withIntermediateDirectories: true, attributes: nil)
        }catch{print(error.localizedDescription)}
        return dirPath!
    }
    
    //MARK: - Load document Directory Folder and Return a Array
    func loadAllFolder() -> [URL]{
        var folderArray : [URL] = []
        var directory = NSSearchPathForDirectoriesInDomains(.documentDirectory, .userDomainMask, true)[0]
        do{
            let folder = try FileManager.default.contentsOfDirectory(at: URL(fileURLWithPath: directory), includingPropertiesForKeys: [.contentTypeKey], options: [.skipsHiddenFiles])
            for fold in folder{
                folderArray.append(fold)
            }
        }catch{}
        return folderArray
    }
}
//MARK: - Collection View DataSource Impliment
extension ViewController : UICollectionViewDataSource{
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        folderNameArray.count
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = imageCollectionView.dequeueReusableCell(withReuseIdentifier: "FolderCollectionViewCell", for: indexPath) as! FolderCollectionViewCell
        cell.folderNameLabel.text = folderNameArray[indexPath.row].lastPathComponent
        cell.editButton.addTarget(self, action: #selector(editButton), for: .touchUpInside)
        return cell
    }
    
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        if let imageCollectinM = UIStoryboard(name: "ImageCollection", bundle: nil).instantiateViewController(withIdentifier: "ImageCollection") as? ImageCollection{
            imageCollectinM.folderPath = folderNameArray[indexPath.row]
            self.navigationController?.pushViewController(imageCollectinM, animated: true)
        }
    }
    
    //MARK: - Edit Button Click Listener
    @objc func editButton(_ sender: UIButton){
        var action = UIAlertController(title: "Edit", message: "Performe What you want", preferredStyle: .actionSheet)
        action.addAction(UIAlertAction(title: "Delete", style: .destructive, handler: { [self] UIAlertAction in
            if let folderItemCell = sender.superview?.superview?.superview as? FolderCollectionViewCell{
                guard let indexpath = imageCollectionView.indexPath(for: folderItemCell) else{return}
                let folderPath = folderNameArray[indexpath.row]
                do{
                    print(folderPath)
                    self.imageCollectionView?.performBatchUpdates({
                        //add your object to data source first
                        folderNameArray.remove(at: indexpath.row)
                        self.imageCollectionView?.deleteItems(at: [indexpath])
                    }, completion: nil)
                    try FileManager.default.removeItem(atPath: folderPath.path)
                }catch{}
            }
        }))
        action.addAction(UIAlertAction(title: "Cencel", style: .cancel, handler: nil))
        self.present(action, animated: true, completion: nil)
    }
}

//MARK: - Collection View Delegate Implimentation-

extension ViewController : UICollectionViewDelegate, UICollectionViewDelegateFlowLayout{
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        CGSize(width: 188.0, height: 220.0)
        //        return CGSize(width: 188, height: 200)
    }
}

