//
//  PreviewImageVC.swift
//  Gellery App
//
//  Created by Appnotrix on 26/1/23.
//

import UIKit

protocol ImageDeleteDeleget : AnyObject{
    func deletedImageURL(imageURL: URL, arrayIndex: Int)
}

class PreviewImageVC: UIViewController {
    
    @IBOutlet weak var previewImage: UIImageView!
    @IBOutlet weak var moreButton: UIButton!
    
    var imgUrlArray : [URL] = []
    var currentImage : Int?
    var imageDeleteDeleget : ImageDeleteDeleget?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        if let currentImage = currentImage {
            previewImage.image = UIImage(contentsOfFile: imgUrlArray[currentImage].path)
        }
    }
    
    @IBAction func closeWindowAction(_ sender: UIButton) {
        self.dismiss(animated: true, completion: nil)
    }
    
    @IBAction func previusImageButton(_ sender: UIButton) {
        if currentImage! > 0{
            currentImage! -= 1
                previewImage.image = UIImage(contentsOfFile: imgUrlArray[currentImage!].path)
        }
    }
    
    @IBAction func btnOptionMenu(_ sender: UIButton) {
        let action = UIAlertController(title: "Option", message: "What you want to performe", preferredStyle: .actionSheet)
        action.addAction(UIAlertAction(title: "Delete Image", style: .destructive, handler: { [self] UIAlertAction in
            do{
                self.imageDeleteDeleget?.deletedImageURL(imageURL: imgUrlArray[currentImage!], arrayIndex: currentImage!)
                try FileManager.default.removeItem(at: imgUrlArray[currentImage!])
                imgUrlArray.remove(at: currentImage!)
//                currentImage! += 1
//                if imgUrlArray.count - 1 > currentImage!{
//                    previewImage.image = UIImage(contentsOfFile: imgUrlArray[currentImage!].path)
//                }else if currentImage! > 0{
//                    previewImage.image = UIImage(contentsOfFile: imgUrlArray[currentImage!].path)
//                }else{
//                    self.dismiss(animated: true, completion: nil)
//                }
                self.dismiss(animated: true, completion: nil)
            }catch{}
        }))
        action.addAction(UIAlertAction(title: "Cencel", style: .cancel, handler: nil))
        self.present(action, animated: true, completion: nil)
    }
    
    @IBAction func nextImageButton(_ sender: UIButton) {
        if imgUrlArray.count - 1 > currentImage!{
            currentImage! += 1
//            if let imageOne = UIImage(contentsOfFile: imgUrlArray[currentImage! - 1].path), let imageTwo = UIImage(contentsOfFile: imgUrlArray[currentImage!].path){
//                let images : [UIImage] = [imageOne,imageTwo]
//                previewImage.animationImages = images
//                previewImage.animationRepeatCount =
//                previewImage.animationDuration = 1.0
//                previewImage.startAnimating()
//            }
            previewImage.image = UIImage(contentsOfFile: imgUrlArray[currentImage!].path)
        }
    }
}
