//
//  ImagePreview.swift
//  Gellery App
//
//  Created by Appnotrix on 26/1/23.
//

import UIKit

class ImagePreview: UIViewController {
    
    var imgUrlArray : [URL] = []
    var currentImage : Int?
    @IBOutlet weak var preveiwImageCollection: UICollectionView!
        
    override func viewDidLoad() {
        super.viewDidLoad()
        preveiwImageCollection.delegate = self
        preveiwImageCollection.dataSource = self
        
        let id = IndexPath(row: currentImage!, section: 0)
        preveiwImageCollection.isPagingEnabled = false
        self.preveiwImageCollection.scrollToItem(at: id, at: [.centeredVertically,.centeredHorizontally], animated: false)
        preveiwImageCollection.isPagingEnabled = true
    }
    
    @IBAction func moveButton(_ sender: UIButton) {
        let docDir = NSURL(fileURLWithPath: NSSearchPathForDirectoriesInDomains(.documentDirectory, .userDomainMask, true)[0])
        let moveDir = docDir.appendingPathComponent("Shamim/munshi")
        
        do{
            if !FileManager.default.fileExists(atPath: moveDir!.path){
                try FileManager.default.createDirectory(at: moveDir!, withIntermediateDirectories: true, attributes: nil)
            }
            let filePath = imgUrlArray[currentImage!]
            try FileManager.default.moveItem(at: filePath, to: moveDir!)
            self.dismiss(animated: true, completion: nil)
        }
        catch{}
    }
    
    @objc func onswipe(_ sender: UISwipeGestureRecognizer){
        if sender.direction == .right{
            if imgUrlArray.count > currentImage!{
                currentImage! += 1
//                previewImageView.image = UIImage(contentsOfFile: imgUrlArray[currentImage!].path)
            }
        }else if sender.direction == .left{
            if currentImage! > -1{
                currentImage! -= 1
//                previewImageView.image = UIImage(contentsOfFile: imgUrlArray[currentImage!].path)
            }
        }
//        self.dismiss(animated: true, completion: nil)
    }
    
    @IBAction func closeViewButton(_ sender: UIButton) {
        self.dismiss(animated: true, completion: nil)
    }
    
}

extension ImagePreview : UICollectionViewDelegate, UICollectionViewDataSource, UICollectionViewDelegateFlowLayout{
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        imgUrlArray.count
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = preveiwImageCollection.dequeueReusableCell(withReuseIdentifier: "cell", for: indexPath) as! PreviewImageCell
        cell.previewImage.image = UIImage(contentsOfFile: imgUrlArray[indexPath.row].path)
        return cell
    }
    
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        let height = view.frame.size.height
        let width = view.frame.size.width
        return CGSize(width: width, height: height)
    }
    
//    func scrollCollectionViewToIndex(itemIndex: IndexPath) {
//            DispatchQueue.main.asyncAfter(deadline: .now() + 0.2) {
//                self.preveiwImageCollection?.scrollToItem(at: itemIndex, at: .centeredHorizontally, animated: true)
//            }
//        }
}

class PreviewImageCell : UICollectionViewCell{
    @IBOutlet weak var previewImage: UIImageView!
}
