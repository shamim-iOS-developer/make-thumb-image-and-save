//
//  ImageCollection.swift
//  Gellery App
//
//  Created by Appnotrix on 25/1/23.
//

import UIKit

class ImageCollection: UIViewController {
    
    @IBOutlet weak var imageCollectionView: UICollectionView!
    @IBOutlet weak var addImageButton: UIButton!
    
    var folderPath: URL?
    var imageURLArray : [URL] = []
    
    override func viewDidLoad() {
        super.viewDidLoad()
        imageCollectionView.dataSource = self
        imageCollectionView.delegate = self
        if let folder = folderPath{
            imageURLArray = loadImage(file: folder)
        }
        imageCollectionView.register(UINib(nibName: "ImagePreviewCell", bundle: nil), forCellWithReuseIdentifier: "ImagePreviewCell")
    }
    
    @IBAction func addImageButtonAction(_ sender: UIButton) {
        if let addImage = UIStoryboard(name: "AddImage", bundle: nil).instantiateViewController(withIdentifier: "AddImage") as? AddImageViewController{
            addImage.folder = folderPath!
            addImage.insertDelegate = self
            self.navigationController?.pushViewController(addImage, animated: true)
        }
    }
    
    func loadImage(file: URL) -> [URL]{
        var imageUrl : [URL] = []
        let directory = NSSearchPathForDirectoriesInDomains(.documentDirectory, .userDomainMask, true).first
        do{
            let imgUrl = try FileManager.default.contentsOfDirectory(at: file, includingPropertiesForKeys: [.contentTypeKey], options: [.skipsHiddenFiles])
            for img in imgUrl{
                imageUrl.append(img)
            }
        }catch{}
        return imageUrl
    }
}

//MARK: - Get Inserted Image URL Using Custom Deleget
extension ImageCollection : DelegateInsertImage{
    func insertImage(imageURL: URL) {
        var indexPath = IndexPath(row: imageURLArray.count, section: 0)
        imageURLArray.append(imageURL)
        imageCollectionView.insertItems(at: [indexPath])
    }
    
    
}

extension ImageCollection : UICollectionViewDataSource{
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        imageURLArray.count
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = imageCollectionView.dequeueReusableCell(withReuseIdentifier: "cell", for: indexPath) as! ImageCollectionCell
        cell.imageView.image = UIImage(contentsOfFile: imageURLArray[indexPath.row].path)
        return cell
    }
    
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        if let vc = UIStoryboard(name: "ImagePreview", bundle: nil).instantiateViewController(withIdentifier: "ImagePreview") as? ImagePreview{
            vc.currentImage = indexPath.row
            vc.imgUrlArray = imageURLArray
            vc.modalPresentationStyle = .fullScreen
            self.present(vc, animated: true, completion: nil)
        }
        
//        if let previewVC = UIStoryboard(name: "PreviewImage", bundle: nil).instantiateViewController(withIdentifier: "PreviewImageVC") as? PreviewImageVC{
//            previewVC.currentImage = indexPath.row
//            previewVC.imgUrlArray = imageURLArray
//            previewVC.imageDeleteDeleget = self
//            previewVC.modalPresentationStyle = .fullScreen
//            self.present(previewVC, animated: true, completion: nil)
//        }
    }
}

extension ImageCollection : ImageDeleteDeleget{
    func deletedImageURL(imageURL: URL, arrayIndex: Int) {
        imageURLArray.remove(at: arrayIndex)
        imageCollectionView.deleteItems(at: [IndexPath(row: arrayIndex, section: 0)])
    }
}

extension ImageCollection : UICollectionViewDelegate, UICollectionViewDelegateFlowLayout{
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        return CGSize(width: 180.0, height: 180.0)
    }
}

class ImageCollectionCell : UICollectionViewCell{
    @IBOutlet weak var imageView: UIImageView!
}
