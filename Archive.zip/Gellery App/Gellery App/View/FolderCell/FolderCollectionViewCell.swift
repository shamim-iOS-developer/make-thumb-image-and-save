//
//  FolderCollectionViewCell.swift
//  Gellery App
//
//  Created by Appnotrix on 25/1/23.
//

import UIKit

class FolderCollectionViewCell: UICollectionViewCell {

    @IBOutlet weak var folderImageView: UIImageView!
    @IBOutlet weak var folderNameLabel: UILabel!
    @IBOutlet weak var editButton: UIButton!
    
    @IBAction func editButtonAction(_ sender: UIButton) {
    }
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

}
