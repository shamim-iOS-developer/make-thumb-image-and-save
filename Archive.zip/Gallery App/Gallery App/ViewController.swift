//
//  ViewController.swift
//  Gallery App
//
//  Created by Appnotrix on 30/1/23.
//

import UIKit
import PhotosUI

class ViewController: UIViewController {
    
    let userDefault = UserDefaults()
    
    @IBOutlet weak var imageCollection: UICollectionView!
    var orginalImageFolderPath: String?
    var thumbnilImageFolderPath: String?

    override func viewDidLoad() {
        super.viewDidLoad()
        
        do{
            let docURL = try FileManager.default.url(for: .picturesDirectory, in: .userDomainMask, appropriateFor: nil, create: true)
            let appnoPath = createDirectory(url: docURL, folderName: "Appnotrix")
            if FileManager.default.fileExists(atPath: appnoPath){
                orginalImageFolderPath = createDirectory(url: URL(fileURLWithPath: appnoPath), folderName: "Main Image")
                orginalImageFolderPath = createDirectory(url: URL(fileURLWithPath: appnoPath), folderName: "Thumb Image")
            }
            debugPrint(appnoPath)
        }catch{}
        
    }
    
    @IBAction func addImageButton(_ sender: UIButton) {
        var phpickerConfig = PHPickerConfiguration()
        phpickerConfig.selectionLimit = 500
        phpickerConfig.filter = .images
        
        let phpickerVC = PHPickerViewController(configuration: phpickerConfig)
        phpickerVC.delegate = self
        self.present(phpickerVC, animated: true, completion: nil)
    }
    
    func createDirectory(url: URL, folderName: String) -> String{
        let folderPath = url.appendingPathComponent(folderName)
        do{
            if !FileManager.default.fileExists(atPath: folderPath.path){
                try FileManager.default.createDirectory(at: folderPath, withIntermediateDirectories: true, attributes: nil)
                return folderPath.path
            }
            return folderPath.path
        }catch{}
        return folderPath.path
    }
}

extension ViewController : PHPickerViewControllerDelegate{
    func picker(_ picker: PHPickerViewController, didFinishPicking results: [PHPickerResult]) {
        dismiss(animated: true, completion: nil)
        
        for i in results{
            i.itemProvider.loadObject(ofClass: UIImage.self) { [self] image, error in
                if let image = image as? UIImage {
                    let thumbImage = makeThumbImage(image: image)
                }
            }
        }
    }
    
    func imageNameGenerator() -> String{
        var count = userDefault.integer(forKey: "count")
        count += 1
        userDefault.set(count, forKey: "count")
        let name = "Image_\(count).jpg"
        return name
    }
    
    func saveThumbImage(imageName: String ,image: UIImage) -> URL{
        var url = URL(fileURLWithPath: thumbnilImageFolderPath!)
        let imgPath = url.appendingPathComponent(imageName)
        if !FileManager.default.fileExists(atPath: imgPath.path){
            let imgData = image.jpegData(compressionQuality: 0.1)
            do{
                try imgData?.write(to: imgPath)
                return imgPath
            }catch{}
        }
        return imgPath
    }
    
    func makeThumbImage(image: UIImage) -> UIImage{
//        let imageData = image.pngData()
//        let options = [
//            kCGImageSourceCreateThumbnailWithTransform: false,
//            kCGImageSourceCreateThumbnailFromImageAlways: true,
//            kCGImageSourceThumbnailMaxPixelSize: 400] as CFDictionary
//        let source = CGImageSourceCreateWithData(imageData! as CFData, nil)!
//        let imageReference = CGImageSourceCreateThumbnailAtIndex(source, 0, options)!
//        let thumbnail = UIImage(cgImage: imageReference)
//        return thumbnail
        
        let imageData = image.pngData()
        let options = [
            kCGImageSourceCreateThumbnailWithTransform: true,
            kCGImageSourceCreateThumbnailFromImageAlways: true,
            kCGImageSourceThumbnailMaxPixelSize: 400] as CFDictionary
        let source = CGImageSourceCreateWithData(imageData! as CFData, nil)!
        let imageReference = CGImageSourceCreateThumbnailAtIndex(source, 0, options)!
        let thumbnail = UIImage(cgImage: imageReference)
        return thumbnail
    }
}

class ImageCollectionCell : UICollectionViewCell{
    @IBOutlet weak var itemImage : UIImageView!
}

