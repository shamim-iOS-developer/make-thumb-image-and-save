////
////  ViewController.swift
////  Thumb Image
////
////  Created by Appnotrix on 26/1/23.
////
//
//import UIKit
//import QuickLook
//
//class ViewController: UIViewController, UIImagePickerControllerDelegate & UINavigationControllerDelegate {
//
//    @IBOutlet weak var thumbImageView: UIImageView!
//
//    override func viewDidLoad() {
//        super.viewDidLoad()
//        // Do any additional setup after loading the view.
//        let action = UIImagePickerController()
//        action.delegate = self
//        self.present(action, animated: true, completion: nil)
//    }
//
//    func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [UIImagePickerController.InfoKey : Any]) {
//        //writeDocDirectory(image: info[.originalImage] as! UIImage)
//        thumbImageView.image = writeDocDirectory(image: info[.originalImage] as! UIImage)
////        var thumbImage = thumbnail(for: url, size: CGSize(width: 180.0, height: 180.0), scale: 2)
//
////        var thumbImage = thumbnil(image: UIImage(contentsOfFile: url)!)
////        var thumbUrl = writeThumbImage(image: thumbImage)
////        thumbImageView.image = UIImage(contentsOfFile: thumbUrl.path)
//        self.dismiss(animated: true, completion: nil)
//    }
//
//    func writeThumbImage(image: UIImage) -> URL{
//        let directory = NSURL(fileURLWithPath: NSSearchPathForDirectoriesInDomains(.documentDirectory, .userDomainMask, true)[0]).appendingPathComponent("Thumb Image")
//        var thumbUrl = directory!
//        if !FileManager.default.fileExists(atPath: directory!.path){
//            do{
//                try FileManager.default.createDirectory(at: directory!, withIntermediateDirectories: true, attributes: nil)
////                writeThumbImage(image: image)
//            }catch{}
//        }else{
//            let imgpath = directory?.appendingPathComponent("thumb.jpg")
//            if let imgData = image.jpegData(compressionQuality: 1), !FileManager.default.fileExists(atPath: imgpath!.path){
//                do{
//                    print("Thumb Image Path",imgpath!.path)
//                    thumbUrl = imgpath!
//                    try imgData.write(to: imgpath!)
//                }catch{}
//            }
//        }
//        return thumbUrl
//    }
//
//    func writeDocDirectory(image: UIImage) -> UIImage{
//        let imgpath: URL?
//        let directory = NSURL(fileURLWithPath: NSSearchPathForDirectoriesInDomains(.documentDirectory, .userDomainMask, true)[0]).appendingPathComponent("Main Image")
////        var url = URL(fileURLWithPath: directory!.path)
//        if !FileManager.default.fileExists(atPath: directory!.path){
//            do{
//                try FileManager.default.createDirectory(at: directory!, withIntermediateDirectories: true, attributes: nil)
//                writeDocDirectory(image: image)
//            }catch{}
//        }else{
//            imgpath = directory!.appendingPathComponent("image.jpg")
//            if let imgData = image.jpegData(compressionQuality: 1), !FileManager.default.fileExists(atPath: imgpath!.path){
//                do{
//                    print(imgpath!.path)
//                    try imgData.write(to: imgpath!)
//                    return UIImage(contentsOfFile: imgpath!.path)!
//
//                }
//                catch{}
//            }
//        }
//        return UIImage(contentsOfFile: imgpath!.path)!
//    }
//
//    func thumbnil(image: UIImage) -> UIImage{
//        let imageData = image.pngData()
//        let options = [
//            kCGImageSourceCreateThumbnailWithTransform: true,
//            kCGImageSourceCreateThumbnailFromImageAlways: true,
//            kCGImageSourceThumbnailMaxPixelSize: 300] as CFDictionary
//        let source = CGImageSourceCreateWithData(imageData as! CFData, nil)!
//        let imageReference = CGImageSourceCreateThumbnailAtIndex(source, 0, options)!
//        let thumbnail = UIImage(cgImage: imageReference)
//        return thumbnail
//    }
//
////    func thumbnail(for fileURL: URL, size: CGSize, scale: CGFloat){
////        var image : UIImage?
////        let request = QLThumbnailGenerator
////            .Request(fileAt: fileURL, size: size, scale: scale,
////                     representationTypes: .lowQualityThumbnail)
////
////        QLThumbnailGenerator.shared.generateRepresentations(for: request)
////        { (thumbnail, type, error) in
////            DispatchQueue.main.async {
////                if thumbnail == nil || error != nil {
////                    // Handle the error case gracefully.
////                } else {
////                    // Display the thumbnail that you created.
////                    image = thumbnail!.uiImage
////                }
////            }
////        }
////
////    }
//}
//


import UIKit
import Foundation
import PhotosUI

class ViewController: UIViewController{
    
    let context = (UIApplication.shared.delegate as! AppDelegate).persistentContainer.viewContext
    
    var imageInfoModel : [Images] = []
    
    let userDefault = UserDefaults.standard
    
    @IBOutlet weak var imageCollectionView: UICollectionView!
    
    var mainImageFolderPath : String?
    var thumbImageFolderPath : String?

    //MARK: - Without Core Data
    //    var mainImagesPath:[URL] = []
//    var thumbImagesPath:[URL] = []
    
    override func viewDidLoad() {
        super.viewDidLoad()
        imageCollectionView.delegate = self
        imageCollectionView.dataSource = self
        
        //MARK: - Create Appnotrix Directory and create two Sub Directory
        do{
            let docURL = try FileManager.default.url(for: .documentDirectory, in: .userDomainMask, appropriateFor: nil, create: true)
            let appnoPath = createDirectory(url: docURL, folderName: "Appnotrix")
            if FileManager.default.fileExists(atPath: appnoPath){
                mainImageFolderPath = createDirectory(url: URL(fileURLWithPath: appnoPath), folderName: "Main Image")
                thumbImageFolderPath = createDirectory(url: URL(fileURLWithPath: appnoPath), folderName: "Thumb Image")
            }
        }catch{}
        
        //MARK: - Load Image url from Main Image and Thumb Image
        //Without Core Data
//        mainImagesPath = loadImage(file: URL(fileURLWithPath: mainImageFolderPath!))
//        thumbImagesPath = loadImage(file: URL(fileURLWithPath: thumbImageFolderPath!))
        
        //MARK: - Load imageInfo model on CoreData
        imageInfoModel = fatchImages()
    }
    
    //MARK: - Load All Image From Spasific Folder
    func loadImage(file: URL) -> [URL]{
        var imageUrl : [URL] = []
        do{
            imageUrl = try FileManager.default.contentsOfDirectory(at: file, includingPropertiesForKeys: [.contentTypeKey], options: [.skipsHiddenFiles])
        }catch{}
        return imageUrl
    }
    
    //MARK: - Pick a image from Device and Save orginal Image in mainImagefolder, make a thumb image and also save it on thumb Image folder
    @IBAction func addImageButton(_ sender: UIButton) {
        
        //MARK: - PHPicker for pick multiple Image.
        var pickerConfig = PHPickerConfiguration()
        pickerConfig.selectionLimit = 500
        pickerConfig.filter = .images
        
        let pickerVC = PHPickerViewController(configuration: pickerConfig)
        pickerVC.delegate = self
        self.present(pickerVC, animated: true, completion: nil)
        
        //MARK: - UI Image Picker Controller
//        let pickImage = UIImagePickerController()
//        pickImage.delegate = self
//        self.present(pickImage, animated: true, completion: nil)
    }
}

//MARK: - After Image Picked
extension ViewController : UIImagePickerControllerDelegate & UINavigationControllerDelegate{
//    func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [UIImagePickerController.InfoKey : Any]) {
//        let pickedImage = info[.originalImage] as! UIImage
//        let thumbImage = thumbnil(image: pickedImage)
//        let mainImageURL = saveOrginalImage(image: pickedImage)
//        // mainImagesPath.append(mainImageURL) ------------------> Without coredata
//        _ = saveThumbImage(image: thumbImage)
//        //let indexPath = IndexPath(row: thumbImagesPath.count, section: 0)----_
//        //thumbImagesPath.append(thumbImageURL)----------~> Without coredata
//
//        //MARK: - Load on Collection View
////        imageCollectionView.insertItems(at: [indexPath])
//
//        let indexPath = IndexPath(row: imageInfoModel.count, section: 0)
//        let savedImageInfo = saveImage(imageName: mainImageURL.lastPathComponent)
//        imageInfoModel.append(savedImageInfo)
//        imageCollectionView.insertItems(at: [indexPath])
//        self.dismiss(animated: true, completion: nil)
//    }
    
    //MARK: - Save Orginal Image on mainImageFolderPath
    func saveOrginalImage(image: UIImage) -> URL{
        let num = userDefault.integer(forKey:"mainImage") + 1
        userDefault.set(num, forKey: "mainImage")
        let filePath = URL(fileURLWithPath: mainImageFolderPath!).appendingPathComponent("Image_\(num).jpg")
        if let imageData = image.jpegData(compressionQuality: 1), !FileManager.default.fileExists(atPath: filePath.path){
            do{
                try imageData.write(to: filePath)
                return filePath
            }catch{}
        }
        return filePath
    }
    
    //MARK: - Save Thumbnil Image on mainImageFolderPath
    func saveThumbImage(image: UIImage) -> URL{
        let num = userDefault.integer(forKey:"thumbImage") + 1
        userDefault.set(num, forKey: "thumbImage")
        let filePath = URL(fileURLWithPath: thumbImageFolderPath!).appendingPathComponent("Image_\(num).jpg")
        if let imageData = image.jpegData(compressionQuality: 0.1), !FileManager.default.fileExists(atPath: filePath.path){
            do{
                try imageData.write(to: filePath)
                return filePath
            }catch{}
        }
        return filePath
    }
    
    //MARK: - Make Thumbnil Image
    func thumbnil(image: UIImage) -> UIImage{
        let imageData = image.pngData()
        let options = [
            kCGImageSourceCreateThumbnailWithTransform: false,
            kCGImageSourceCreateThumbnailFromImageAlways: true,
            kCGImageSourceThumbnailMaxPixelSize: 400] as CFDictionary
        let source = CGImageSourceCreateWithData(imageData! as CFData, nil)!
        let imageReference = CGImageSourceCreateThumbnailAtIndex(source, 0, options)!
        let thumbnail = UIImage(cgImage: imageReference)
        return thumbnail
    }
}

//MARK: - PHPicker View Controller Delegate
extension ViewController : PHPickerViewControllerDelegate{
    func picker(_ picker: PHPickerViewController, didFinishPicking results: [PHPickerResult]) {
        var pickedMultiImages = [UIImage]()
        
        for result in results {
            result.itemProvider.loadObject(ofClass: UIImage.self) { [self] object, error in
                if let pickedImage = object as? UIImage{
                    pickedMultiImages.append(pickedImage)
                    
                    if let pickedImage = object as? UIImage{
                        let thumbImage = thumbnil(image: pickedImage)
                        let mainImageURL = saveOrginalImage(image: pickedImage)
                        // mainImagesPath.append(mainImageURL) ------------------> Without coredata
                        _ = saveThumbImage(image: thumbImage)
                        //let indexPath = IndexPath(row: thumbImagesPath.count, section: 0)----_
                        //thumbImagesPath.append(thumbImageURL)----------~> Without coredata
                        
                        //MARK: - Load on Collection View
                //        imageCollectionView.insertItems(at: [indexPath])
                        
                        let indexPath = IndexPath(row: imageInfoModel.count, section: 0)
                        let savedImageInfo = saveImage(imageName: mainImageURL.lastPathComponent)
                        DispatchQueue.main.async {
                            imageInfoModel.append(savedImageInfo)
                            imageCollectionView.insertItems(at: [indexPath])
                        }
                    }
                }
            }
        }
        
//        results.first?.itemProvider.loadObject(ofClass: UIImage.self, completionHandler: { [self] object, error in
//            if let pickedImage = object as? UIImage{
//                let thumbImage = thumbnil(image: pickedImage)
//                let mainImageURL = saveOrginalImage(image: pickedImage)
//                // mainImagesPath.append(mainImageURL) ------------------> Without coredata
//                _ = saveThumbImage(image: thumbImage)
//                //let indexPath = IndexPath(row: thumbImagesPath.count, section: 0)----_
//                //thumbImagesPath.append(thumbImageURL)----------~> Without coredata
//
//                //MARK: - Load on Collection View
//        //        imageCollectionView.insertItems(at: [indexPath])
//
//                let indexPath = IndexPath(row: imageInfoModel.count, section: 0)
//                let savedImageInfo = saveImage(imageName: mainImageURL.lastPathComponent)
//                DispatchQueue.main.async {
//                    imageInfoModel.append(savedImageInfo)
//                    imageCollectionView.insertItems(at: [indexPath])
//                }
//            }
//        })
        self.dismiss(animated: true, completion: nil)
    }
}

//MARK: - Collection View Data Source and Delegate
extension ViewController : UICollectionViewDataSource, UICollectionViewDelegate, UICollectionViewDelegateFlowLayout{
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        imageInfoModel.count
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = imageCollectionView.dequeueReusableCell(withReuseIdentifier: "cell", for: indexPath) as! ImageCell
        let path = thumbImageFolderPath!.appending("/"+imageInfoModel[indexPath.row].image_name!)
        cell.image.image = UIImage(contentsOfFile: path)
        return cell
    }
    
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        if let detailVC = UIStoryboard(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "DetailViewController") as? DetailViewController{
            let path = mainImageFolderPath!+"/"+imageInfoModel[indexPath.row].image_name!
//            print(path)
            detailVC.imgUrl = URL(fileURLWithPath:path)
            self.present(detailVC, animated: true, completion: nil)
        }
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        return CGSize(width: 200, height: 200)
    }
}

//MARK: - Create Appnotrix Directory Under Document Directory
extension ViewController{
    func createDirectory(url: URL, folderName: String) -> String{
        let folderPath = url.appendingPathComponent(folderName)
        do{
            if !FileManager.default.fileExists(atPath: folderPath.path){
                try FileManager.default.createDirectory(at: folderPath, withIntermediateDirectories: true, attributes: nil)
                return folderPath.path
            }
            return folderPath.path
        }catch{}
        return folderPath.path
    }
}

//MARK: - Core Data Save and Fatch
extension ViewController{
    func fatchImages() -> [Images]{
        var imgModel : [Images] = []
        do{
            try imgModel = context.fetch(Images.fetchRequest())
        }catch{}
        return imgModel
    }
    
    func saveImage(imageName: String) -> Images{
        let img = Images(context: context)
        img.image_name = imageName
        img.create_date = Date.now
        do{
            try context.save()
        }catch{print("Error")}
        return img
    }
}


//MARK: - Collection View Cell Class
class ImageCell : UICollectionViewCell{
    @IBOutlet weak var image : UIImageView!
}

//MARK: - Detail View Controller
class DetailViewController: UIViewController{
    @IBOutlet weak var detailImageView: UIImageView!
    var imgUrl: URL?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        if let imgUrl = imgUrl {
            detailImageView.image = UIImage(contentsOfFile: imgUrl.path)
        }
    }
}
