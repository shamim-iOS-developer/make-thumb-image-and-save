//
//  Images+CoreDataClass.swift
//  Thumb Image
//
//  Created by Appnotrix on 27/1/23.
//
//

import Foundation
import CoreData

@objc(Images)
public class Images: NSManagedObject {

}
