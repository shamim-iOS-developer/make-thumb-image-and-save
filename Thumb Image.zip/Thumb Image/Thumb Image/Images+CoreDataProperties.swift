//
//  Images+CoreDataProperties.swift
//  Thumb Image
//
//  Created by Appnotrix on 27/1/23.
//
//

import Foundation
import CoreData


extension Images {

    @nonobjc public class func fetchRequest() -> NSFetchRequest<Images> {
        return NSFetchRequest<Images>(entityName: "Images")
    }

    @NSManaged public var create_date: Date?
    @NSManaged public var image_name: String?

}

extension Images : Identifiable {

}
